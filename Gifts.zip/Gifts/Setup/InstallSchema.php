<?php

namespace PixieMedia\Gifts\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
		$installer = $setup;
		$installer->startSetup();

		/**
		 * Creating table pixiemedia_gifts
		 */
		if (!$installer->tableExists('pixiemedia_gifts')) {
			$table = $installer->getConnection()->newTable(
				$installer->getTable('pixiemedia_gifts')
			)->addColumn(
				'gifts_id',
				\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
				null,
				['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
				'Entity Id'
			)->addColumn(
				'promotion_title',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				255,
				['nullable' => true],
				'Promotion Title'
			)->addColumn(
				'product_option_name',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				255,
				['nullable' => true,'default' => null],
				'Product Option Name'
			)->addColumn(
				'store_id',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				255,
				['nullable' => true,'default' => null],
				'Store Id'
			)->addColumn(
				'status',
				\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
				1,
				['nullable' => false,'default' => 0],
				'Gift Status'
			)->addColumn(
				'free_text_editor_block',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				'2M',
				['nullable' => true,'default' => null],
				'Free Text Editor Block'
			)->addColumn(
				'free_text',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				255,
				['nullable' => true,'default' => null],
				'Free Text Sash Field'
			)->addColumn(
				'free_text_colour',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				255,
				['nullable' => true,'default' => null],
				'Free Text Colour'
			)->addColumn(
				'free_text_bg_colour',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				255,
				['nullable' => true,'default' => null],
				'Free Text BG Colour'
			)->addColumn(
				'product_assigned',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				255,
				['nullable' => true,'default' => null],
				'Assigned Product'
			)->addColumn(
				'start_date',
				\Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
				null,
				['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT],
				'Start Date'
			)->addColumn(
				'stop_date',
				\Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
				null,
				['nullable' => true,'default' => null],
				'End Date')
			->setComment(
	            'PixieMedia Gifts Table'
	        );
			$installer->getConnection()->createTable($table);
		}

		if (!$installer->tableExists('pixiemedia_gifts_product_rel')) {
            $table = $installer->getConnection()
                ->newTable(
                	$installer->getTable('pixiemedia_gifts_product_rel')
                )->addColumn(
                	'gifts_id', 
                	\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 
                	10, 
                	[
                		'nullable' => false, 
                		'unsigned' => true
                	]
            	)->addColumn(
                	'product_id', 
                	\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 
                	10, 
                	[
                		'nullable' => false, 
                		'unsigned' => true
                	], 
                	'Magento Product Id'
                )
                ->addForeignKey(
                    $installer->getFkName(
                        'pixiemedia_gifts',
                        'gifts_id',
                        'pixiemedia_gifts_product_rel',
                        'gifts_id'
                    ),
                    'gifts_id',
                    $installer->getTable('pixiemedia_gifts'),
                    'gifts_id',
                    \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
                )
                ->addForeignKey(
                    $installer->getFkName(
                        'pixiemedia_gifts_product_rel',
                        'gifts_id',
                        'catalog_product_entity',
                        'entity_id'
                    ),
                    'product_id',
                    $installer->getTable('catalog_product_entity'),
                    'entity_id',
                    \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
                )
                ->setComment('PixieMedia Product Gift Relation Table');

            $installer->getConnection()->createTable($table);
        }
		$installer->endSetup();
	}
}