<?php
/**
 * @category   PixieMedia
 * @package    PixieMedia_Gifts
 * @author     info@pixie.agency
 * @copyright  Pixie Media 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace PixieMedia\Gifts\Model;

use Magento\Framework\Model\AbstractModel;

class Gifts extends AbstractModel
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('PixieMedia\Gifts\Model\ResourceModel\Gifts');
    }

    public function getProducts(\PixieMedia\Gifts\Model\Gifts $object)
    {
        $tbl = $this->getResource()->getTable(\PixieMedia\Gifts\Model\ResourceModel\Gifts::TBL_ATT_PRODUCT);
        $select = $this->getResource()->getConnection()->select()->from(
            $tbl,
            ['product_id']
        )
        ->where(
            'gifts_id = ?',
            (int)$object->getId()
        );
        return $this->getResource()->getConnection()->fetchCol($select);
    }
}