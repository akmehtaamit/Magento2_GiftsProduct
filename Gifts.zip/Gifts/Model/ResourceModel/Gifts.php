<?php
/**
 * @category   PixieMedia
 * @package    PixieMedia_Gifts
 * @author     info@pixie.agency
 * @copyright  Pixie Media 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace PixieMedia\Gifts\Model\ResourceModel;

class Gifts extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    const TBL_ATT_PRODUCT = 'pixiemedia_gifts_product_rel';
    /**
     * Define main table
     */
    public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context,
        $resourcePrefix = null
    ) {
        parent::__construct($context, $resourcePrefix);
    }
    protected function _construct()
    {
        $this->_init('pixiemedia_gifts', 'gifts_id');   //here "pixiemedia_gifts" is table name and "gifts_id" is the primary key of custom table
    }
}