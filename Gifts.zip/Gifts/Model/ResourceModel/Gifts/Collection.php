<?php
/**
 * @category   PixieMedia
 * @package    PixieMedia_Gifts
 * @author     info@pixie.agency
 * @copyright  Pixie Media 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace PixieMedia\Gifts\Model\ResourceModel\Gifts;
 
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'gifts_id';
    /**
     * Define model & resource model
     */
    protected function _construct()
    {
        $this->_init(
            'PixieMedia\Gifts\Model\Gifts',
            'PixieMedia\Gifts\Model\ResourceModel\Gifts'
        );
    }
}