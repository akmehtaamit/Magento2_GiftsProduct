<?php
/**
 * @category   PixieMedia
 * @package    PixieMedia_Gifts
 * @author     info@pixie.agency
 * @copyright  Pixie Media 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace PixieMedia\Gifts\Controller\Adminhtml\Items;

class NewAction extends \PixieMedia\Gifts\Controller\Adminhtml\Items
{

    public function execute()
    {
        $this->_forward('edit');
    }
}
