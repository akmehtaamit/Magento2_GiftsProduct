<?php
/**
 * @category   PixieMedia
 * @package    PixieMedia_Gifts
 * @author     info@pixie.agency
 * @copyright  Pixie Media 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace PixieMedia\Gifts\Controller\Adminhtml\Items;

class Save extends \PixieMedia\Gifts\Controller\Adminhtml\Items
{
    public function execute()
    {
        if ($this->getRequest()->getPostValue()) {
            try {
                $model = $this->_objectManager->create('PixieMedia\Gifts\Model\Gifts');
                $data = $this->getRequest()->getPostValue();
                $data['store_id'] = implode(',', $this->getRequest()->getParam('store_id'));

                    
                $inputFilter = new \Zend_Filter_Input(
                    [],
                    [],
                    $data
                );
                $data = $inputFilter->getUnescaped();
                $id = $this->getRequest()->getParam('id');
                if ($id) {
                    $model->load($id);
                    if ($id != $model->getId()) {
                        throw new \Magento\Framework\Exception\LocalizedException(__('The wrong gift is specified.'));
                    }
                }
                $model->setData($data);
                $session = $this->_objectManager->get('Magento\Backend\Model\Session');
                $session->setPageData($model->getData());
                $model->save();
                $this->saveProducts($model, $data);
                $this->messageManager->addSuccess(__('You saved the gift.'));
                $session->setPageData(false);
                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('pixiemedia_gifts/*/edit', ['id' => $model->getId()]);
                    return;
                }
                $this->_redirect('pixiemedia_gifts/*/');
                return;
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
                $id = (int)$this->getRequest()->getParam('id');
                if (!empty($id)) {
                    $this->_redirect('pixiemedia_gifts/*/edit', ['id' => $id]);
                } else {
                    $this->_redirect('pixiemedia_gifts/*/new');
                }
                return;
            } catch (\Exception $e) {
                $this->messageManager->addError(
                    __('Something went wrong while saving the gift data. Please review the error log.')
                );
                $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
                $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData($data);
                $this->_redirect('pixiemedia_gifts/*/edit', ['id' => $this->getRequest()->getParam('id')]);
                return;
            }
        }
        $this->_redirect('pixiemedia_gifts/*/');
    }

    public function saveProducts($model, $post)
    {
        // Attach the attachments to contact
        if (isset($post['product_assigned'])) {
            $productIds = $this->decodeGridSerializedInput($post['product_assigned']);
            try {
                $oldProducts = (array) $model->getProducts($model);
                $newProducts = (array) $productIds;

                $this->_resources = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\App\ResourceConnection');
                $connection = $this->_resources->getConnection();

                $table = $this->_resources->getTableName(\PixieMedia\Gifts\Model\ResourceModel\Gifts::TBL_ATT_PRODUCT);
                $insert = array_diff($newProducts, $oldProducts);
                $delete = array_diff($oldProducts, $newProducts);

                if ($delete) {
                    $where = ['gifts_id = ?' => (int)$model->getId(), 'product_id IN (?)' => $delete];
                    $connection->delete($table, $where);
                }

                if ($insert) {
                    $data = [];
                    foreach ($insert as $product_id) {
                        $data[] = ['gifts_id' => (int)$model->getId(), 'product_id' => (int)$product_id];
                    }
                    $connection->insertMultiple($table, $data);
                }
            } catch (Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the gift.'));
            }
        }

    }
    public function decodeGridSerializedInput($encoded)
    {
        $isSimplified = false === strpos($encoded, '=');
        $result = [];
        parse_str($encoded, $decoded);
        foreach ($decoded as $key => $value) {
            if (is_numeric($key)) {
                if ($isSimplified) {
                    $result[] = $key;
                } else {
                    $result[$key] = null;
                    parse_str(base64_decode($value), $result[$key]);
                }
            }
        }
        return $result;
    }

    public function printLog($responseJson){
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/customoptionlog.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info(print_r($responseJson,true));
    }
}
