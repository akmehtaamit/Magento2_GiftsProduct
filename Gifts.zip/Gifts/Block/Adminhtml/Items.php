<?php
/**
 * @category   PixieMedia
 * @package    PixieMedia_Gifts
 * @author     info@pixie.agency
 * @copyright  Pixie Media 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace PixieMedia\Gifts\Block\Adminhtml;

class Items extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller = 'items';
        $this->_headerText = __('Gifts');
        $this->_addButtonLabel = __('Add New Gift');
        parent::_construct();
    }
}
