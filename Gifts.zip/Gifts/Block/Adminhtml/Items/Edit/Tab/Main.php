<?php
/**
 * @category   PixieMedia
 * @package    PixieMedia_Gifts
 * @author     info@pixie.agency
 * @copyright  Pixie Media 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace PixieMedia\Gifts\Block\Adminhtml\Items\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;

class Main extends Generic implements TabInterface
{
    protected $_wysiwygConfig;
 
    public function __construct(
        \Magento\Backend\Block\Template\Context $context, 
        \Magento\Framework\Registry $registry, 
        \Magento\Framework\Data\FormFactory $formFactory,  
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig, 
        \Magento\Store\Model\System\Store $systemStore,
        array $data = []
    ) 
    {
        $this->_wysiwygConfig = $wysiwygConfig;
        $this->_systemStore = $systemStore;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * {@inheritdoc}
     */
    public function getTabLabel()
    {
        return __('Gifts Information');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('Gifts Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return $this
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('current_pixiemedia_gifts_items');
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('gift_');
        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Gifts Information')]);
        if ($model->getId()) {
            $fieldset->addField('gifts_id', 'hidden', ['name' => 'gifts_id']);
        }

        $fieldset->addField(
            'status',
            'select',
            ['name' => 'status', 'label' => __('Status'), 'title' => __('Status'),  'options'   => [0 => 'Disable', 1 => 'Enable'], 'required' => true]
        );
        $fieldset->addField(
            'promotion_title',
            'text',
            ['name' => 'promotion_title', 'label' => __('Promotion Title'), 'title' => __('Promotion Title'), 'required' => true]
        );
        $fieldset->addField(
            'product_option_name',
            'text',
            ['name' => 'product_option_name', 'label' => __('Product Option Name'), 'title' => __('Product Option Name'), 'required' => true]
        );
        $fieldset->addField(
            'free_text',
            'text',
            ['name' => 'free_text', 'label' => __('Free Text Sash Field'), 'title' => __('Free Text Sash Field'), 'required' => true]
        );
        $fieldset->addField(
            'free_text_colour',
            'text',
            ['name' => 'free_text_colour', 'label' => __('Sash Text Colour'), 'title' => __('Sash Text Colour'), 'required' => true]
        );
		 $fieldset->addField(
            'free_text_bg_colour',
            'text',
            ['name' => 'free_text_bg_colour', 'label' => __('Sash Text Background Colour'), 'title' => __('Sash Text Background Colour'), 'required' => true]
        );
		
        $fieldset->addField(
           'store_id',
           'multiselect',
           [
             'name'     => 'store_id[]',
             'label'    => __('Store Views'),
             'title'    => __('Store Views'),
             'required' => true,
             'values'   => $this->_systemStore->getStoreValuesForForm(false, true),
           ]
        );
        $fieldset->addField(
            'free_text_editor_block',
            'editor',
            [
                'name' => 'free_text_editor_block',
                'label' => __('Free Text Editor'),
                'title' => __('Free Text Editor'),
                'style' => 'height:26em;',
                'required' => false,
                'config'    => $this->_wysiwygConfig->getConfig(),
                'wysiwyg' => true
            ]
        );
         $fieldset->addField(
            'start_date',
            'date',
            [
                'name'  => 'start_date',
                'label' => __('Start Showing '),
                'title' => __('Start Showing '),
                'required' => false,
                'date_format' => $this->_localeDate->getDateFormat(
                    \IntlDateFormatter::LONG
                ),
                'class' => 'validate-date',
            ]
        );
        $fieldset->addField(
            'stop_date',
            'date',
            [
                'name'  => 'stop_date',
                'label' => __('Stop Showing'),
                'title' => __('Stop Showing'),
                'required' => false,
                'date_format' => $this->_localeDate->getDateFormat(
                    \IntlDateFormatter::LONG
                ),
                'class' => 'validate-date',
            ]
        );
        
        $form->setValues($model->getData());
        $this->setForm($form);
        return parent::_prepareForm();
    }
}
