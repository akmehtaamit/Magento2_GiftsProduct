<?php

namespace PixieMedia\Gifts\Block;

use Magento\Framework\View\Element\Template\Context;

class Gifts extends \Magento\Framework\View\Element\Template implements \Magento\Widget\Block\BlockInterface
{
    protected $giftsFactory;

    protected $dTime;

    protected $_registry;

    public function __construct(
        Context $context,
        \PixieMedia\Gifts\Model\ResourceModel\Gifts\CollectionFactory $giftsFactory,
        \Magento\Framework\Stdlib\DateTime\DateTime $dTime,
        \Magento\Framework\Registry $registry,
        array $data = array()
    ) {
        $this->_giftsFactory = $giftsFactory;
        $this->dTime = $dTime;
        $this->_registry = $registry;
        parent::__construct($context, $data);
    }
    public function getCollection(){
        $magentoDateObject = $this->dTime;
        $date = $magentoDateObject->gmtDate();
        $GiftsData = $this->_giftsFactory->create()
            ->addFieldToFilter('start_date', ['lteq' => $date])
            ->addFieldToFilter('stop_date', ['gteq' => $date])
            ->addFieldToFilter('status',1);
        return $GiftsData;
    }
    public function getCurrentProduct()
    {        
        return $this->_registry->registry('current_product');
    } 
}