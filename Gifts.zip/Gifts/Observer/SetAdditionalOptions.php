<?php

namespace PixieMedia\Gifts\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Serialize\SerializerInterface;

class SetAdditionalOptions implements ObserverInterface
{
    protected $request;
    private $serializer;
    protected $giftsFactory;
    protected $dTime;
    protected $_productloader;

    public function __construct(
        RequestInterface $request,
        \PixieMedia\Gifts\Model\ResourceModel\Gifts\CollectionFactory $giftsFactory,
        \Magento\Framework\Stdlib\DateTime\DateTime $dTime,
        \Magento\Catalog\Model\ProductFactory $_productloader,
        SerializerInterface $serializer
    )
    {
        $this->_giftsFactory = $giftsFactory;
        $this->dTime = $dTime;
        $this->request = $request;
        $this->serializer = $serializer;
        $this->_productloader = $_productloader;
    }

    public function execute(EventObserver $observer)
    {
        $magentoDateObject = $this->dTime;
        $date = $magentoDateObject->gmtDate();
        $GiftsData = $this->_giftsFactory->create()
            ->addFieldToFilter('start_date', ['lteq' => $date])
            ->addFieldToFilter('stop_date', ['gteq' => $date])
            ->addFieldToFilter('status',1);

        foreach ($GiftsData as $giftData) {
            $item = $observer->getQuoteItem();
            $productIds = $this->decodeGridSerializedInput($giftData['product_assigned']);
            $store_id = explode(',', $giftData['store_id']);
            $product=$this->getLoadProduct($item->getProductId());
            $storeID = $product->getStoreId();
            if (in_array($storeID, $store_id) || in_array('0', $store_id)) {
                if (in_array($item->getProductId(), $productIds)) {
                    
                    $additionalOptions = array();
                    if ($additionalOption = $item->getOptionByCode('additional_options')) {
                        $additionalOptions = $this->serializer->unserialize($additionalOption->getValue());
                    }
                     // Without any condition add option
                     $additionalOptions[] = [
                            'label' => $giftData['product_option_name'],
                            'value' => $giftData['free_text'],
                        ];

                    if (count($additionalOptions) > 0) {
                        $item->addOption(array(
                            'product_id' => $item->getProductId(),
                            'code' => 'additional_options',
                            'value' => $this->serializer->serialize($additionalOptions)
                        ));
                    }
                    //$this->printLog($giftData['promotion_title']);
                }
            }
        }
    }
    public function printLog($responseJson){
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/customoptionsave.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info(print_r($responseJson,true));
    }
    public function decodeGridSerializedInput($encoded)
    {
        $isSimplified = false === strpos($encoded, '=');
        $result = [];
        parse_str($encoded, $decoded);
        foreach ($decoded as $key => $value) {
            if (is_numeric($key)) {
                if ($isSimplified) {
                    $result[] = $key;
                } else {
                    $result[$key] = null;
                    parse_str(base64_decode($value), $result[$key]);
                }
            }
        }
        return $result;
    }
    public function getLoadProduct($id)
    {
        return $this->_productloader->create()->load($id);
    }
}