<?php
/**
 * @category   PixieMedia
 * @package    PixieMedia_Gifts
 * @author     info@pixie.agency
 * @copyright  Pixie Media 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'PixieMedia_Gifts',
    __DIR__
);
